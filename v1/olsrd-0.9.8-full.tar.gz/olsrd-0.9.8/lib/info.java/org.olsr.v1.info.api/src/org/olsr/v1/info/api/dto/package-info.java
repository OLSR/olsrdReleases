@org.osgi.annotation.versioning.Version("2.0.0")
package org.olsr.v1.info.api.dto;